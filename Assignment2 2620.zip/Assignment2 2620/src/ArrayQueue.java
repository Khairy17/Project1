
public  class ArrayQueue implements Queue {
	private int head,tail;
	private int capacity;
	public static Element queue[];

ArrayQueue(int cap){
	capacity=cap;
	head=0;
	tail=0;
	queue=new Element[capacity];
}
//override the method from the interface
public void enQueue(Element e) {
	if (queueFull()) {
		System.out.println("Queue is full");
	}
	
	else {
		queue[tail]=e;
		//checking if the tail points at the end of the queue
		// in this case, we have to wrap it up to the front
		if (tail == queue.length - 1 ) {			
			tail = 0;
		}
		else {
			
			tail=tail+1;			// incrementing the tail if it does not reach the end
		}
		  
	}
	
}
public Element deQueue() {
	Element element=null;
	// checking if the queue is empty or not
	if(queueEmpty()) {
		System.out.println("queue is empty");
		return null; 	
		}
	
	// assigning the head pointer to the element we are dequeuing
	element = queue[head];
	// if the pointer head reach the end of the queue, then we have to wrap it up to the front again
	if (head == queue.length - 1 ) {			
		head = 0;
		
	}
	else {
		// if the pointer head is not at the end of the queue, then we can increment it 
		head=head+1;			
	}
	  	//returning the dequeued element
	return element;
	

}
public boolean queueEmpty() {
	// checking if queue is empty 
	return false;
	
	/*boolean result = true;
	if (head == tail) {
		
		return result;
		
	}
	else {
		
		result = false;
		return result;
	
	}
	
	*/
}
public boolean queueFull() {
	// checking if the queue is full 
	boolean result = true;
	if (head == tail + 1) {
		
		return result;
		
	}
	else {
		
		result = false;
		return result;
	}
}
public int getHeadValue() {
	// returning the head value
	return queue[head].getKeyValue();
	
}
public int getTailValue() {
	// returning the 
	return queue[tail].getKeyValue();
}


}