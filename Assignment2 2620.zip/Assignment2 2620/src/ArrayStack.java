
public class ArrayStack implements Stack {
	private int size; 
	private Element[] data;
	private int top=0; 
	public ArrayStack(int capacity) {
		size=capacity;
		data=(Element[])new Element[size];
	}
	public void push(Element e) {
		if(stackFull()) {
			System.out.println("it is full");
		}
		else {
			data[top]=e;
			top++;
		}
	}
	public Element pop() {
		Element element;
		if(stackEmpty()) {
			System.out.println("stack is empty");
			return null;
		}
		else {
			top--;
			element=data[top];
			data[top]=null;
			//top--;
			return element;
		}
	}
	public boolean stackFull() {
		boolean result = true;
		if (data[size - 1] != null) {
			
			return result;
			
		}
		else {
			
			result = false;
			return result;
			
		}
		
	
	}
	
	public boolean stackEmpty() {
		boolean result=true ;
		if(top<0)
			return result;
		else
			result =false;
		return result;
	}
	public int getTopValue() {
		// 
		return data[top].getKeyValue();
		
	}
	
}
