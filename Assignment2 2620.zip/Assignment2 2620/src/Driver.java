
public class Driver {
	public static void main(String args[]) {
		Driver d=new Driver();
		int upper=9;
		int lower=0;
		ArrayStack s=new ArrayStack(10);
		ArrayQueue q=new ArrayQueue(10);
		int i;
		for (i=0;i<10;i++) {
           int k=(int)(Math.random()*(upper-lower))+lower;	
		s.push(new Element(i,i+""));	
	}	
		Element element2=null;
		for (int j=0;j<10;j++) {
	           element2 = s.pop();
			   q.enQueue(element2);
		}
		
		Element element3=null;
		for (int k=0;k<10;k++) {
	           element3 = q.deQueue();
			s.push(element3);	
		}
		// for test purpose 
	for ( int j = 0; j < 10; j ++) {
		
		//System.out.println(s.pop().getKeyValue());	

		System.out.println(s.pop().getKeyValue());		
	}	
		
	System.out.println("-------------------");
		
	
	
	
	
}
}
